public class Main
{
    public static void main(String[] args)
    {
        Circle c = new Circle();
        c.makeVisible();

        Square s = new Square();
        s.makeVisible();

        Triangle t = new Triangle();
        t.makeVisible();

        Person p = new Person();
        p.makeVisible();
    }
}
